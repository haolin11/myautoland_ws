#for test , not good for get data
#replaced use  ntrip_qx.py 
cd /home/ubuntu/tools/RTKLIB_EX/app/consapp/str2str/gcc
./str2str -in ntrip://xqxwndg001x:x09e741bx@rtk.ntrip.qxwz.com:8002/RTCM32_GGB  -out serial://ttyUSB0:38400 -p 23.0649554 113.055371 20.898  
