^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package ublox
^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.4.1 (2020-06-04)
------------------

1.4.0 (2020-05-28)
------------------
* Bump CMake minimum version to 3.0.2
* Contributors: Gonçalo Pereira

1.3.1 (2020-03-12)
------------------
* Add metapackage dependencies
* Contributors: Mateusz Sadowski, Tim Clephas

1.3.0 (2020-01-10)
------------------

1.2.0 (2019-11-19)
------------------

1.1.2 (2017-08-02)
------------------
* README and package xml updates
* Contributors: Veronica Lane

1.1.0 (2017-07-17)
------------------
* Updated package xmls with new version number and corrected my email address. Also updated readme to include information about new version plus new parameter
* README and ublox package version
* Contributors: Veronica Lane

1.0.0 (2017-06-23)
------------------
* added myself as maintainer to package xmls and updated version numbers of modified packages.
* Contributors: Veronica Lane

0.0.5 (2016-08-06)
------------------

0.0.4 (2014-12-08)
------------------

0.0.3 (2014-10-18)
------------------
* Updated readme to reflect changes
* Contributors: Gareth Cross

0.0.2 (2014-10-03)
------------------

0.0.1 (2014-08-15)
------------------

0.0.0 (2014-06-23)
------------------
* ublox: first commit
* Contributors: Chao Qu
