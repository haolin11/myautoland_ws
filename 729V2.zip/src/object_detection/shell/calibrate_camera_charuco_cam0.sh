rosrun prometheus_detection calibrate_camera_charuco -w=5 -h=7 -sl=0.0345 -ml=0.0207 -d=6 -ci=0 calib.yaml
