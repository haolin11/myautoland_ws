rosrun prometheus_detection create_board_charuco -w=5 -h=7 -sl=200 -ml=120 -d=6 board_charuco_d6.png
