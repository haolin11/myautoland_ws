cd /home/ubuntu/tools/RTKLIB/app/consapp/str2str/gcc
./str2str -in ntrip://rtk2go.com:2101/aamakinen  -out serial://ttyUSB0:38400
